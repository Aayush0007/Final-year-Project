import style from "./Home.module.css";
import pic1 from "../../images/1.png";
import pic2 from "../../images/2.png";
import pic3 from "../../images/3.jpg";
import { NavLink } from "react-router-dom";

function Home() {
    return (
        <div className={style.container}>
            <div className={style.header}>
                <div className={style.headerHeadingBox}>
                    <h3>Online Exam System</h3>
                </div>
            </div>

            <div className={style.content}>
                <div className={style.banner}>
                    <img src={pic1} alt="Online Exam" className={style.bannerImage} />
                    <h2 className={style.bannerTitle}>Online Exam</h2>
                </div>

                <div className={style.options}>
                    <div className={style.option}>
                        <NavLink exact to="/StudentLogin" className={`${style.link} ${style.student}`}>
                            <img src={pic2} alt="Student Login" className={style.optionImage} />
                            <h3 className={style.optionTitle}>Student</h3>
                        </NavLink>
                    </div>

                    <div className={style.option}>
                        <NavLink to="/AdminLogin" className={`${style.link} ${style.admin}`}>
                            <img src={pic3} alt="Admin Login" className={style.optionImage} />
                            <h3 className={style.optionTitle}>Admin</h3>
                        </NavLink>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Home;
