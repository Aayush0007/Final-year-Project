import style from "./Dashboard.module.css";
import { useState, useEffect } from "react";
import { useHistory } from "react-router-dom";
import axios from "axios";

function Dashboard() {
    const [exam, setExam] = useState("Updating...");
    const [question, setQuestion] = useState("Updating...");
    const [user, setUser] = useState("Updating...");

    useEffect(() => {
        async function fetchData() {
            try {
                const examResponse = await axios.get("http://localhost:3333/exam");
                const questionResponse = await axios.get("http://localhost:3333/question");
                const userResponse = await axios.get("http://localhost:3333/user");

                setExam(`We have total ${examResponse.data.length} exams`);
                setQuestion(`We have total ${questionResponse.data.length} questions`);
                setUser(`We have total ${userResponse.data.length} users`);
            } catch (error) {
                console.error("Error fetching data:", error);
            }
        }
        fetchData();
    }, []);

    const history = useHistory();

    const showExam = () => history.push("/AdminDashboard/Exam");
    const showQuestions = () => history.push("/AdminDashboard/Question");
    const showUsers = () => history.push("/AdminDashboard/StudentList");

    return (
        <div className={style.dashboardContainer}>
            <h1 className={style.heading}>Dashboard</h1>

            <div className={style.card}>
                <div className={style.cardContent}>
                    <p className={style.countOfExam}>{exam}</p>
                    <button onClick={showExam}>View Details</button>
                </div>
            </div>

            <div className={style.card}>
                <div className={style.cardContent}>
                    <p className={style.countOfQuestion}>{question}</p>
                    <button onClick={showQuestions}>View Details</button>
                </div>
            </div>

            <div className={style.card}>
                <div className={style.cardContent}>
                    <p className={style.countOfUser}>{user}</p>
                    <button onClick={showUsers}>View Details</button>
                </div>
            </div>
        </div>
    );
}

export default Dashboard;
